@props(['message' => $emptyMessage])

<tr class="text-center empty-message-row">
    <td colspan="100%" class="text-center">
        <div class="p-5">
            <img src="{{ asset('assets/images/empty_box.png') }}" class="empty-message">
            <span class="d-block">{{ __($message) }}</span>
            <span class="d-block fs-13 text-muted">@lang('There are no available data to display on this table at the moment.')</span>
        </div>
    </td>
</tr>
