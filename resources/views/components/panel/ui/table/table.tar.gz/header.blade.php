<thead>{{ $slot }}</thead>
